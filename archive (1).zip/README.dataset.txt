# Defects > 2024-10-13 9:16am
https://universe.roboflow.com/w-esczz/defects-1gsgd

Provided by a Roboflow user
License: CC BY 4.0

